// Set the backend base URL for the handoff endpoint.
// Leave blank to use the same origin as the Item View host.
window.APP_CONFIG = {
  apiBaseUrl: "https://design-automation-assistant-api.onrender.com",
};
